var searchData=
[
  ['mymatrix',['MyMatrix',['../class_my_matrix.html#ab1ff87572b350796c34a7126ecad58e3',1,'MyMatrix::MyMatrix(size_t m, size_t n)'],['../class_my_matrix.html#ad2a30d6517575ce1fafe79846fd0b0a3',1,'MyMatrix::MyMatrix(const MyMatrix &amp;matrix)']]]
];
