var indexSectionsWithContent =
{
  0: "bcdfgimoprstuw~",
  1: "dgmpsuw",
  2: "bcdfgimoprstw~",
  3: "fgim",
  4: "o",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Friends",
  5: "Pages"
};

