var searchData=
[
  ['searchspace',['SearchSpace',['../class_search_space.html',1,'']]]
];
